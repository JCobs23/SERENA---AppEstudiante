using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// HU: Atenuar la interfaz de la tablet durante la proyección e iluminarla al activarse una decisión.
///
/// Escenario 1: si está en proyección y el estudiante no toca la tablet durante X segundos,
///              la interfaz se oscurece suavemente.
/// Escenario 2: al llamar ActivarDecision(), la interfaz se ilumina por completo y no se
///              atenúa hasta que se llame FinalizarDecision().
///
/// Funciona con una capa negra (Image) encima de toda la UI que NO bloquea los toques.
/// </summary>
public class ControlIluminacion : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("Image negra a pantalla completa, último hijo del Canvas.")]
    [SerializeField] private Image capaOscura;

    [Header("Atenuación (Escenario 1)")]
    [Tooltip("Qué tan oscura queda la interfaz: 0 = nada, 1 = negro total.")]
    [SerializeField, Range(0f, 0.85f)] private float oscuridadAtenuado = 0.6f;
    [Tooltip("Segundos sin tocar la tablet antes de atenuar.")]
    [SerializeField] private float segundosSinInteraccion = 5f;
    [Tooltip("¿Empieza en modo proyección?")]
    [SerializeField] private bool enProyeccion = true;

    [Header("Transición")]
    [Tooltip("Segundos que tarda en oscurecer.")]
    [SerializeField] private float duracionAtenuar = 1.2f;
    [Tooltip("Segundos que tarda en iluminar (más rápido para llamar la atención).")]
    [SerializeField] private float duracionIluminar = 0.4f;

    [Header("Brillo real de la pantalla (opcional, solo en dispositivo)")]
    [Tooltip("Además de la capa, cambia el brillo físico de la pantalla. Probar en la tablet: no todos los dispositivos lo permiten.")]
    [SerializeField] private bool cambiarBrilloPantalla = false;
    [SerializeField, Range(0.05f, 1f)] private float brilloAtenuado = 0.3f;
    [SerializeField, Range(0.05f, 1f)] private float brilloNormal = 1f;

    [Header("Eventos")]
    public UnityEvent alAtenuar;
    public UnityEvent alIluminar;

    [Header("Prueba en el editor")]
    [Tooltip("D = activar/finalizar decisión · P = activar/desactivar proyección")]
    [SerializeField] private bool teclasPrueba = true;

    public bool EnDecision { get; private set; }
    public bool Atenuado { get; private set; }

    private float ultimaInteraccion;
    private float oscuridadActual;

    private void Start()
    {
        ultimaInteraccion = Time.unscaledTime;
        if (capaOscura != null)
        {
            capaOscura.raycastTarget = false; // no bloquea los toques
            AplicarOscuridad(0f);
        }
    }

    // ---------- Métodos para llamar desde otros scripts o botones ----------

    /// <summary>Escenario 2: hay que decidir en la tablet → iluminar.</summary>
    public void ActivarDecision()
    {
        EnDecision = true;
        ultimaInteraccion = Time.unscaledTime;
    }

    /// <summary>La decisión terminó (p. ej. el estudiante respondió).</summary>
    public void FinalizarDecision()
    {
        EnDecision = false;
        ultimaInteraccion = Time.unscaledTime;
    }

    public void IniciarProyeccion()   { enProyeccion = true;  ultimaInteraccion = Time.unscaledTime; }
    public void TerminarProyeccion()  { enProyeccion = false; }

    // ----------------------------------------------------------------------

    private void Update()
    {
        if (teclasPrueba) RevisarTeclasPrueba();
        if (HayInteraccion()) ultimaInteraccion = Time.unscaledTime;

        bool debeAtenuar = enProyeccion
                           && !EnDecision
                           && Time.unscaledTime - ultimaInteraccion >= segundosSinInteraccion;

        if (debeAtenuar != Atenuado)
        {
            Atenuado = debeAtenuar;
            if (Atenuado) alAtenuar?.Invoke(); else alIluminar?.Invoke();
        }

        float objetivo = Atenuado ? oscuridadAtenuado : 0f;
        float duracion = Atenuado ? duracionAtenuar : duracionIluminar;
        float paso = oscuridadAtenuado / Mathf.Max(0.01f, duracion) * Time.unscaledDeltaTime;
        float nueva = Mathf.MoveTowards(oscuridadActual, objetivo, paso);

        if (!Mathf.Approximately(nueva, oscuridadActual)) AplicarOscuridad(nueva);
    }

    private void AplicarOscuridad(float valor)
    {
        oscuridadActual = valor;
        if (capaOscura != null)
        {
            Color c = capaOscura.color;
            c.a = valor;
            capaOscura.color = c;
        }

        if (cambiarBrilloPantalla && !Application.isEditor)
        {
            float t = oscuridadAtenuado > 0f ? valor / oscuridadAtenuado : 0f;
            Screen.brightness = Mathf.Lerp(brilloNormal, brilloAtenuado, t);
        }
    }

    private static bool HayInteraccion()
    {
#if ENABLE_INPUT_SYSTEM
        if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.isPressed) return true;
        if (Mouse.current != null && (Mouse.current.leftButton.isPressed || Mouse.current.delta.ReadValue().sqrMagnitude > 0.01f)) return true;
        if (Keyboard.current != null && Keyboard.current.anyKey.isPressed) return true;
        return false;
#else
        return Input.touchCount > 0
               || Input.GetMouseButton(0)
               || Mathf.Abs(Input.GetAxis("Mouse X")) > 0.01f
               || Mathf.Abs(Input.GetAxis("Mouse Y")) > 0.01f
               || Input.anyKey;
#endif
    }

    private void RevisarTeclasPrueba()
    {
#if ENABLE_INPUT_SYSTEM
        bool d = Keyboard.current != null && Keyboard.current.dKey.wasPressedThisFrame;
        bool p = Keyboard.current != null && Keyboard.current.pKey.wasPressedThisFrame;
#else
        bool d = Input.GetKeyDown(KeyCode.D);
        bool p = Input.GetKeyDown(KeyCode.P);
#endif
        if (d)
        {
            if (EnDecision) FinalizarDecision(); else ActivarDecision();
            Debug.Log("Decisión activa: " + EnDecision);
        }
        if (p)
        {
            if (enProyeccion) TerminarProyeccion(); else IniciarProyeccion();
            Debug.Log("En proyección: " + enProyeccion);
        }
    }
}
