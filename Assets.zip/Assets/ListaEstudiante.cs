using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

/// <summary>
/// Maneja el panel "Lista de Estudiantes" y el contador "Connected Students".
/// Llama a ActualizarEstudiante() desde tu capa de red cada vez que cambie un estudiante.
/// </summary>
public class ListaEstudiantes : MonoBehaviour
{
    [SerializeField] private FilaEstudiante prefabFila;
    [SerializeField] private Transform contenedor;
    [SerializeField] private TMP_Text contador;
    [Tooltip("{0} = número de estudiantes conectados")]
    [SerializeField] private string formatoContador = "Connected Students: <color=#D93025><b>{0}</b></color>";

    private readonly Dictionary<string, FilaEstudiante> filas = new Dictionary<string, FilaEstudiante>();

    public int Conectados => filas.Values.Count(f => f.Estado == EstadoConexion.Conectado);

    public void ActualizarEstudiante(string id, string nombre, EstadoConexion estado)
    {
        if (!filas.TryGetValue(id, out FilaEstudiante fila))
        {
            fila = Instantiate(prefabFila, contenedor);
            filas[id] = fila;
        }
        fila.Configurar(nombre, estado);
        ActualizarContador();
    }

    public void QuitarEstudiante(string id)
    {
        if (filas.TryGetValue(id, out FilaEstudiante fila))
        {
            Destroy(fila.gameObject);
            filas.Remove(id);
            ActualizarContador();
        }
    }

    public EstadoConexion? EstadoDe(string id) =>
        filas.TryGetValue(id, out FilaEstudiante f) ? f.Estado : (EstadoConexion?)null;

    private void ActualizarContador()
    {
        if (contador != null) contador.text = string.Format(formatoContador, Conectados);
    }
}
