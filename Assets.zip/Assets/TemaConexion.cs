using System;
using UnityEngine;

/// <summary>Estados estándar de conexión (H.U.3.2.2).</summary>
public enum EstadoConexion
{
    Desconectado, // aún no ha ingresado
    Cargando,     // conectando / esperando
    Conectado,    // ingreso exitoso
    Error         // falló la conexión
}

/// <summary>
/// Set estándar de colores, íconos y textos para cada estado.
/// Crear en: Assets > Create > Serena > Tema de conexión.
/// Colores elegidos con contraste >= 3:1 sobre blanco (WCAG 1.4.11).
/// </summary>
[CreateAssetMenu(fileName = "TemaConexion", menuName = "Serena/Tema de conexión")]
public class TemaConexion : ScriptableObject
{
    [Serializable]
    public class Estilo
    {
        public Color color;
        [Tooltip("Opcional. Si se deja vacío se usa el ícono generado por código.")]
        public Sprite icono;
        public string etiqueta;

        public Estilo(Color color, string etiqueta)
        {
            this.color = color;
            this.etiqueta = etiqueta;
        }
    }

    // Forma del ícono entre paréntesis: así el estado no depende solo del color.
    public Estilo conectado = new Estilo(new Color32(0x1E, 0x8E, 0x3E, 0xFF), "Connected");        // verde  ~4.1:1, círculo con ✓
    public Estilo error = new Estilo(new Color32(0xD9, 0x30, 0x25, 0xFF), "Connection error"); // rojo   ~4.5:1, círculo con ✕
    public Estilo cargando = new Estilo(new Color32(0xB0, 0x60, 0x00, 0xFF), "Connecting…");      // ámbar  ~4.6:1, anillo girando
    public Estilo desconectado = new Estilo(new Color32(0x5F, 0x63, 0x68, 0xFF), "Offline");          // gris   ~6.0:1, anillo vacío

    public Estilo Obtener(EstadoConexion estado)
    {
        switch (estado)
        {
            case EstadoConexion.Conectado: return conectado;
            case EstadoConexion.Error: return error;
            case EstadoConexion.Cargando: return cargando;
            default: return desconectado;
        }
    }

    private static TemaConexion porDefecto;

    /// <summary>Tema usado si un indicador no tiene uno asignado.</summary>
    public static TemaConexion PorDefecto
    {
        get
        {
            if (porDefecto == null) porDefecto = CreateInstance<TemaConexion>();
            return porDefecto;
        }
    }
}
