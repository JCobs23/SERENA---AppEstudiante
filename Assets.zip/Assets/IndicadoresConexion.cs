using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Indicador visual de un estado de conexión: ícono (forma + color) y texto opcional.
/// Úsalo en la fila de cada estudiante y en la barra "Waiting for the other participants...".
/// </summary>
public class IndicadorConexion : MonoBehaviour
{
    /// <summary>Accesibilidad: si es true, el ícono de "cargando" no gira.</summary>
    public static bool ReducirMovimiento;

    [SerializeField] private TemaConexion tema;
    [SerializeField] private Image icono;
    [Tooltip("Opcional. Texto que acompaña al ícono.")]
    [SerializeField] private TMP_Text etiqueta;
    [SerializeField] private bool mostrarEtiqueta = true;
    [Tooltip("Pinta también el texto con el color del estado.")]
    [SerializeField] private bool colorearEtiqueta = false;
    [SerializeField] private EstadoConexion estadoInicial = EstadoConexion.Desconectado;
    [SerializeField, Range(0.25f, 2f)] private float vueltasPorSegundo = 1f;

    public EstadoConexion Estado { get; private set; }
    public event Action<EstadoConexion> CambioEstado;

    private bool iniciado;

    private void Awake()
    {
        if (tema == null) tema = TemaConexion.PorDefecto;
        if (!iniciado) Aplicar(estadoInicial, null);
    }

    /// <summary>Cambia el estado usando el texto estándar del tema.</summary>
    public void SetEstado(EstadoConexion estado) => SetEstado(estado, null);

    /// <summary>Cambia el estado con un texto propio (ej. "Waiting for the other participants...").</summary>
    public void SetEstado(EstadoConexion estado, string textoPersonalizado)
    {
        if (tema == null) tema = TemaConexion.PorDefecto;
        bool cambio = !iniciado || estado != Estado;
        Aplicar(estado, textoPersonalizado);
        if (cambio) CambioEstado?.Invoke(estado);
    }

    private void Aplicar(EstadoConexion estado, string texto)
    {
        iniciado = true;
        Estado = estado;
        TemaConexion.Estilo estilo = tema.Obtener(estado);

        if (icono != null)
        {
            icono.sprite = estilo.icono != null ? estilo.icono : IconosConexion.Obtener(estado);
            icono.color = estilo.color;
            icono.preserveAspect = true;
            icono.rectTransform.localRotation = Quaternion.identity;
        }

        if (etiqueta != null)
        {
            etiqueta.gameObject.SetActive(mostrarEtiqueta);
            etiqueta.text = string.IsNullOrEmpty(texto) ? estilo.etiqueta : texto;
            if (colorearEtiqueta) etiqueta.color = estilo.color;
        }
    }

    private void Update()
    {
        if (Estado == EstadoConexion.Cargando && !ReducirMovimiento && icono != null)
            icono.rectTransform.Rotate(0f, 0f, -360f * vueltasPorSegundo * Time.unscaledDeltaTime);
    }
}
