using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Genera por código los íconos de estado (blancos, se tiñen con Image.color).
/// Así funcionan sin importar imágenes; se pueden reemplazar por sprites propios en el TemaConexion.
///   Conectado    → círculo lleno con ✓
///   Error        → círculo lleno con ✕
///   Cargando     → anillo con un hueco (gira)
///   Desconectado → anillo vacío
/// </summary>
public static class IconosConexion
{
    private const int N = 128;
    private static readonly Dictionary<EstadoConexion, Sprite> cache = new Dictionary<EstadoConexion, Sprite>();

    public static Sprite Obtener(EstadoConexion estado)
    {
        if (cache.TryGetValue(estado, out Sprite s) && s != null) return s;
        s = Crear(estado);
        cache[estado] = s;
        return s;
    }

    private static Sprite Crear(EstadoConexion estado)
    {
        var tex = new Texture2D(N, N, TextureFormat.RGBA32, false)
        {
            filterMode = FilterMode.Bilinear,
            wrapMode = TextureWrapMode.Clamp,
            name = "Icono_" + estado
        };

        var px = new Color32[N * N];
        float aa = 1.5f / N; // suavizado de bordes
        for (int y = 0; y < N; y++)
            for (int x = 0; x < N; x++)
            {
                var p = new Vector2((x + 0.5f) / N, (y + 0.5f) / N);
                byte a = (byte)(Mathf.Clamp01(Alfa(estado, p, aa)) * 255f);
                px[y * N + x] = new Color32(255, 255, 255, a);
            }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, N, N), new Vector2(0.5f, 0.5f), N);
    }

    private static float Alfa(EstadoConexion estado, Vector2 p, float aa)
    {
        var c = new Vector2(0.5f, 0.5f);
        float r = Vector2.Distance(p, c);
        float circulo = Cubre(r - 0.46f, aa);
        const float trazo = 0.065f;

        switch (estado)
        {
            case EstadoConexion.Conectado:
                {
                    float d = Mathf.Min(
                        Segmento(p, new Vector2(0.27f, 0.50f), new Vector2(0.43f, 0.34f)),
                        Segmento(p, new Vector2(0.43f, 0.34f), new Vector2(0.74f, 0.66f))) - trazo;
                    return circulo * (1f - Cubre(d, aa)); // ✓ recortado
                }
            case EstadoConexion.Error:
                {
                    float d = Mathf.Min(
                        Segmento(p, new Vector2(0.32f, 0.32f), new Vector2(0.68f, 0.68f)),
                        Segmento(p, new Vector2(0.32f, 0.68f), new Vector2(0.68f, 0.32f))) - trazo;
                    return circulo * (1f - Cubre(d, aa)); // ✕ recortada
                }
            case EstadoConexion.Cargando:
                {
                    float a = Cubre(Mathf.Abs(r - 0.36f) - 0.08f, aa);
                    float ang = Mathf.Atan2(p.y - 0.5f, p.x - 0.5f) * Mathf.Rad2Deg;
                    if (ang > 0f && ang < 90f) a *= 0.2f; // hueco que se nota al girar
                    return a;
                }
            default:
                return Cubre(Mathf.Abs(r - 0.38f) - 0.07f, aa);
        }
    }

    // d < 0 = dentro de la figura
    private static float Cubre(float d, float aa) => Mathf.Clamp01(0.5f - d / aa);

    private static float Segmento(Vector2 p, Vector2 a, Vector2 b)
    {
        Vector2 ab = b - a;
        float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / ab.sqrMagnitude);
        return Vector2.Distance(p, a + ab * t);
    }
}

