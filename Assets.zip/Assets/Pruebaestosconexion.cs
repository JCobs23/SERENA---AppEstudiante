using System.Collections;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Herramienta de PRUEBA (tarea 3). Ponla en un objeto vacío de la escena.
/// Teclas: 1 Desconectado · 2 Cargando · 3 Conectado · 4 Error
///         5 Llenar la lista de ejemplo · 6 Simular ingreso OK · 7 Simular ingreso fallido
///         M Activar/desactivar "reducir movimiento"
/// También disponibles con clic derecho sobre el componente (menú contextual).
/// Quítala o desactívala antes de publicar.
/// </summary>
public class PruebaEstadosConexion : MonoBehaviour
{
    [SerializeField] private IndicadorConexion indicadorPropio; // barra "Waiting for..."
    [SerializeField] private ListaEstudiantes lista;
    [SerializeField] private float segundosSimulados = 2f;

    private static readonly string[] Nombres =
    {
        "María González", "Juan Pérez", "Ana Rodríguez", "Carlos Martínez",
        "Laura Sánchez", "Diego López", "Sofía García", "Miguel Torres"
    };

    private void Update()
    {
        if (Tecla(1)) Poner(EstadoConexion.Desconectado);
        if (Tecla(2)) Poner(EstadoConexion.Cargando);
        if (Tecla(3)) Poner(EstadoConexion.Conectado);
        if (Tecla(4)) Poner(EstadoConexion.Error);
        if (Tecla(5)) LlenarLista();
        if (Tecla(6)) SimularIngresoOk();
        if (Tecla(7)) SimularIngresoFallido();
        if (TeclaM())
        {
            IndicadorConexion.ReducirMovimiento = !IndicadorConexion.ReducirMovimiento;
            Debug.Log("Reducir movimiento: " + IndicadorConexion.ReducirMovimiento);
        }
    }

    private void Poner(EstadoConexion e)
    {
        if (indicadorPropio != null) indicadorPropio.SetEstado(e);
        Debug.Log("Estado propio → " + e);
    }

    [ContextMenu("Llenar lista (todos los estados)")]
    public void LlenarLista()
    {
        if (lista == null) return;
        var estados = (EstadoConexion[])System.Enum.GetValues(typeof(EstadoConexion));
        for (int i = 0; i < Nombres.Length; i++)
            lista.ActualizarEstudiante("est" + i, Nombres[i], estados[i % estados.Length]);
        Debug.Log($"Lista llenada. Conectados: {lista.Conectados} (esperado: 2)");
    }

    [ContextMenu("Simular ingreso OK")]
    public void SimularIngresoOk() => StartCoroutine(Simular(true));

    [ContextMenu("Simular ingreso fallido")]
    public void SimularIngresoFallido() => StartCoroutine(Simular(false));

    private IEnumerator Simular(bool exito)
    {
        indicadorPropio.SetEstado(EstadoConexion.Cargando);
        yield return new WaitForSecondsRealtime(segundosSimulados);
        if (exito) indicadorPropio.SetEstado(EstadoConexion.Conectado, "Waiting for the other participants...");
        else indicadorPropio.SetEstado(EstadoConexion.Error, "Could not connect. Tap to retry.");
        Debug.Log("Simulación terminada → " + indicadorPropio.Estado);
    }

    private static bool Tecla(int n)
    {
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current == null) return false;
        var teclas = new[] { Key.Digit1, Key.Digit2, Key.Digit3, Key.Digit4, Key.Digit5, Key.Digit6, Key.Digit7 };
        return Keyboard.current[teclas[n - 1]].wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.Alpha0 + n);
#endif
    }

    private static bool TeclaM()
    {
#if ENABLE_INPUT_SYSTEM
        return Keyboard.current != null && Keyboard.current.mKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.M);
#endif
    }
}
