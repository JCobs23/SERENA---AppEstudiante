using TMPro;
using UnityEngine;

/// <summary>Una fila de la "Lista de Estudiantes": indicador + nombre.</summary>
public class FilaEstudiante : MonoBehaviour
{
    [SerializeField] private TMP_Text nombre;
    [SerializeField] private IndicadorConexion indicador;

    public EstadoConexion Estado => indicador.Estado;

    public void Configurar(string nombreEstudiante, EstadoConexion estado)
    {
        nombre.text = nombreEstudiante;
        indicador.SetEstado(estado);
        gameObject.name = "Fila_" + nombreEstudiante;
    }
}
