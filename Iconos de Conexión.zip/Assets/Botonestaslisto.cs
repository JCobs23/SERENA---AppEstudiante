using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Botón rojo "¿Estás listo?" que al presionarlo cambia a verde "¡Listo!"
/// y muestra el mensaje "Conectado".
/// Ponlo en el mismo objeto que el Button.
/// </summary>
[RequireComponent(typeof(Button))]
public class BotonEstasListo : MonoBehaviour
{
    [Header("Botón")]
    [Tooltip("Texto del botón. Si se deja vacío, lo busca solo dentro del botón.")]
    [SerializeField] private TMP_Text texto;
    [SerializeField] private Color colorRojo = new Color32(0xD3, 0x2F, 0x2F, 0xFF);
    [SerializeField] private Color colorVerde = new Color32(0x1E, 0x8E, 0x3E, 0xFF);
    [SerializeField] private string textoInicial = "¿Estás listo?";
    [SerializeField] private string textoListo = "¡Listo!";

    [Header("Mensaje")]
    [Tooltip("Texto donde aparece el mensaje. Empieza oculto.")]
    [SerializeField] private TMP_Text mensaje;
    [Tooltip("Opcional. Panel que contiene el mensaje (si usas un fondo detrás del texto).")]
    [SerializeField] private GameObject panelMensaje;
    [SerializeField] private string textoMensaje = "Conectado";

    private Button boton;
    private Image fondo;

    private void Awake()
    {
        boton = GetComponent<Button>();
        fondo = boton.targetGraphic as Image;
        if (texto == null) texto = GetComponentInChildren<TMP_Text>();

        fondo.color = colorRojo;
        texto.text = textoInicial;
        MostrarMensaje(false);

        boton.onClick.AddListener(MarcarListo);
    }

    private void MarcarListo()
    {
        fondo.color = colorVerde;
        texto.text = textoListo;

        if (mensaje != null) mensaje.text = textoMensaje;
        MostrarMensaje(true);
    }

    private void MostrarMensaje(bool visible)
    {
        if (panelMensaje != null) panelMensaje.SetActive(visible);
        else if (mensaje != null) mensaje.gameObject.SetActive(visible);
    }
}
